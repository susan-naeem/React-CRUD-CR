import { useParams } from "react-router-dom";
import "../App.css"

function UserDetail({users}){
    const {id} = useParams()
    console.log(id);
    

    const user = users[parseInt(id)]

    return <section className="user-detail-container">
        <img src={user.pic} alt={user.name} className="user-profile-pic"/>
        <div>
            <h2>{user.name}</h2>
            <p>{user.bio}</p>
        </div>
    </section>
}

export default UserDetail