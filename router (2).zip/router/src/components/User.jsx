import { useNavigate } from "react-router-dom"
import "../App.css"

function User({name, pic,id}){
    const navigate = useNavigate()
    return <section className="user-container" onClick={()=> navigate("/user/"+id)}>
        <img src={pic} alt={name} className="user-profile-pic"/>
        <h2>Hello , {name}</h2>
    </section>
}

export default User