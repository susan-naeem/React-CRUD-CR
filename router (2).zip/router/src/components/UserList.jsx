import User from "./User"
import "../App.css"

function UserList({users}){
    return <div className="user-list-container">
        {users.map((x,index)=> <User name={x.name} pic={x.pic} id={index}/>)}
    </div>
}
export default UserList