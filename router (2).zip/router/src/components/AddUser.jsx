import { useState } from "react";
import "../App.css"
import axios from "axios";

function AddUser(){
    const [name, setName] = useState("")
    const [pic, setPic] = useState("")
    const [bio, setBio] = useState("")

    const userAdd = async()=>{
        const user = {
            name : name,
            pic : pic,
            bio :bio
        }
    const response = await axios.post("https://6afc161a892984c4494ac686.mockapi.io/users",user)
    console.log(response.status);
    alert("Status Code :"+response.status+" User Added")
    
    }

    return <div className="user-container">
        <h1>Add New User</h1>
        <input type="text" value={name} onChange={(e)=>setName(e.target.value)}/>
        <br />
        <input type="text" value={pic} onChange={(e)=>setPic(e.target.value)}/>
        <br />
        <input type="text" value={bio} onChange={(e)=>setBio(e.target.value)}/>
        <br />
        <button onClick={userAdd}>Add</button>
    </div>
}

export default AddUser