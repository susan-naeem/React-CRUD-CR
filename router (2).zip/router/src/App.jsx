import { Routes, Route,Link } from "react-router-dom"
import Home from "./components/Home"
import Wrong from "./components/Wrong"
import UserList from "./components/UserList"
import "./App.css"
import UserDetail from "./components/UserDetail"
import { useEffect, useState } from "react"
import axios from 'axios'
import AddUser from "./components/AddUser"

function App(){
  const [myUser, setMyUser] = useState([])

  const getUserData = async()=>{
    const response = await axios.get("https://6afc161a892984c4494ac686.mockapi.io/users") 
    console.log(response.status);
    setMyUser(response.data)
  }

  useEffect(
    ()=>{
      getUserData()
    },[]
  )

return <>
<nav className="nav-list">
  <Link to="/">Home </Link>
  <Link to="/user"> User</Link>
  <Link to="/add-new"> Add User</Link>
</nav>
<Routes>
  <Route path="/" element={<Home/>}/>
  <Route path="/user" element={<UserList users={myUser}/>}/>
  <Route path="/user/:id" element={<UserDetail users={myUser}/>}/>
  <Route path="/add-new" element={<AddUser/>}/>
  <Route path="*" element={<Wrong/>}/>
</Routes>
</>
}

export default App